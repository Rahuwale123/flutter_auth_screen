import 'package:auth/auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: FirebaseOptions(
    apiKey: 'AIzaSyDSDIpuy8w8N397fbky6A5eivr1JBE3L8I',
    appId: 'AIzaSyDSDIpuy8w8N397fbky6A5eivr1JBE3L8I',
    messagingSenderId: 'AIzaSyDSDIpuy8w8N397fbky6A5eivr1JBE3L8I',
    projectId: 'AIzaSyDSDIpuy8w8N397fbky6A5eivr1JBE3L8I',));
  runApp(app());
}

class app extends StatelessWidget {
  const app({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'auth screen',
      home: auth(),
    );
  }
}
