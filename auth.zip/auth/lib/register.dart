
import 'package:auth/login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}
class _RegisterState extends State<Register> {
  final TextEditingController email = TextEditingController();
  final TextEditingController username = TextEditingController();
  final TextEditingController password = TextEditingController();
  void reg() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: email.text, password: password.text);
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Account successfully created"),
            actions: [
              TextButton(onPressed: (){
       Navigator.pop(context);
              }, child: Text("Ok"))
            ],
          );
        },
      );
    } on FirebaseAuthException catch (e) {
       showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text(e.code),
            actions: [
              TextButton(onPressed: (){
       Navigator.pop(context);
              }, child: Text("Ok"))
            ],
          );
        },
      );
    }
  }
User? user;
  Future<void> signingoogle() async{
  try {
   UserCredential userCredential= await FirebaseAuth.instance.signInWithPopup(GoogleAuthProvider());
   user=userCredential.user;
    
  } catch (e) {
    print(e);
  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 230, 229, 229),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 80,
            ),
            Text(
              "Welcome lets create account",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(
              height: 25,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Container(
                color: Colors.white,
                child: TextField(
                  controller: username,
                  decoration: InputDecoration(
                      fillColor: Colors.white,
                      focusColor: Colors.white,
                      labelText: 'username',
                      labelStyle: TextStyle(color: Colors.grey),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.transparent))),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Container(
                color: Colors.white,
                child: TextField(
                  controller: email,
                  decoration: InputDecoration(
                      fillColor: Colors.white,
                      focusColor: Colors.white,
                      labelText: 'email',
                      labelStyle: TextStyle(color: Colors.grey),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.transparent))),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Container(
                color: Colors.white,
                child: TextField(
                  controller: password,
                  decoration: InputDecoration(
                      fillColor: Colors.white,
                      focusColor: Colors.white,
                      labelText: 'password',
                      labelStyle: TextStyle(color: Colors.grey),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.transparent))),
                ),
              ),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: GestureDetector(
                onTap: () {
                  reg();
                },
                child: Container(
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(27),
                    color: Colors.pink,
                  ),
                  width: double.infinity,
                  child: Center(
                      child: Text(
                    "register",
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  )),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(children: <Widget>[
                Expanded(child: Divider()),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text("or continue with"),
                ),
                Expanded(child: Divider()),
              ]),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () async{
                   
                    },
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 230, 229, 229),
                          border: Border.all(color: Colors.white)),
                      child: Image.asset('assets/images/google.png'),
                    ),
                  ),
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        color: Color.fromARGB(255, 230, 229, 229),
                        border: Border.all(color: Colors.white)),
                    child: Image.asset('assets/images/facebook.png'),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("alerady a member?"),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context,MaterialPageRoute(builder: (context)=>login()));
                    },
                    child: Text(
                      "  login now",
                      style: TextStyle(
                          fontWeight: FontWeight.w800, color: Colors.blue),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      )),
    );
  }
}
